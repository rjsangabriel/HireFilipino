<?php


/*
 Template Name: Project Search
 */

get_header(); ?>  
<body class="bg-job">
<div class="spacer10">&nsbp;</div>

    <div class="col-lg-12">
<div class="col-lg-6">
<img src="/wp-content/themes/hirefilipino/img/logo-header.png">
</div>
<div class="col-lg-6">
<h3 class="alignright"><strong>Project Lists</strong></h3>
</div>
</div>
   
    <div class="col-lg-3">
  <div class="col-lg-12 job-box">
     <?php echo do_shortcode("[acps id='537']"); ?>
     </div>
     </div>
     <div class="col-lg-9">
      <?php 
 global $current_user; 
 if ( user_can( $current_user, "employer" ) ){
 echo "&nbsp;"; 
 } 
 else{ 
 echo "<a href='/my-profile/project-management/new-project/' class='btn btn-primary btn'>Add New Project</a>"; 
 }
 ?>
 <div class="col-lg-12 group-box">
     <?php echo do_shortcode("[acps_results]"); ?>
     </div>
     </div>
     
     
     </body>
<!-- Loop End -->
  <?php get_footer(); ?>

