<?php
/*
* @Author 		PickPlugins
* Copyright: 	2015 PickPlugins.com
*/

if ( ! defined('ABSPATH')) exit;  // if direct access 




	$cookie_name = 'job_bm_view';
	$job_id = get_the_ID();
	$job_bm_view_count = get_post_meta(get_the_ID(),'job_bm_view_count', true);
	
	
	if(isset($_COOKIE[$cookie_name.'_'.$job_id])){
		
			//var_dump($_COOKIE[$cookie_name.'_'.$q_id]);
			//var_dump($job_bm_view_count);		
			
		}
	else{
			//var_dump('No');
		
			setcookie( $cookie_name.'_'.$job_id, $job_id, time() + (86400 * 30)); // 86400 = 1 day
			
			update_post_meta(get_the_ID(), 'job_bm_view_count', ($job_bm_view_count+1));
		}



		get_header();
		
		

		do_action('job_bm_action_before_single_job');

		while ( have_posts() ) : the_post(); 
		?>
        <div class="bg-job">
<div class="spacer10">&nsbp;</div>
<div class="container">
<div class="col-lg-12">
<div class="col-lg-6">
<img src="/wp-content/themes/hirefilipino/img/logo-header.png">
</div>
<div class="col-lg-6">
<h3 class="alignright"><strong><?php the_ID(); ?></strong></h3>
</div>
<div class="col-lg-12 listing-categories">
 					<ol class="breadcrumb">
                    <li>Categories:</li>
                    <li><a href="/job-listings/?job_cat=arts">Arts</a></li>
                    <li><a href="/job-listings/?job_cat=media">Media</a></li>
                    <li><a href="/job-listings/?job_cat=services">Services</a></li>
                    <li><a href="/job-listings/?job_cat=teaching">Teaching</a></li>
                    <li><a href="/job-listings/?job_cat=business">Business</a></li>
                    <li><a href="/job-listings/?job_cat=legal">Legal</a></li>
                    <li><a href="/job-listings/?job_cat=technology">Technology</a></li>
                    <li><a href="/job-listings/?job_cat=other">Other</a></li>
                    <li class="alignright"><?php echo date('l jS F Y'); ?></li>
                    </ol>
                     
                    </div>
</div>

 <div class="col-lg-12 list-box">
   
         <h5>Post Submitted by: <?php the_author(); ?></h5>
     
        <div itemscope itemtype="http://schema.org/JobPosting" id="job-<?php the_ID(); ?>" <?php post_class('job-single entry-content'); ?>>
        

		<?php
			do_action('job_bm_action_single_job_main');
		?>
        
         <button class="btn-primary" onclick="goBack()">Go Back</button>

<script>
function goBack() {
    window.history.back();
}
</script>
        <div class="clear"></div>
        </div>
		   

     </div>
     </div>
     </div>
		
		<?php
		endwhile;
        do_action('job_bm_action_after_single_job');

		get_footer();
		
		
