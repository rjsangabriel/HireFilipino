<?php 
/*
 Template Name: Standard dark bg
 */
 get_header(); ?>
 

<?php get_sidebar('user'); ?>


<div class="col-sm-10 bg-cont">

 <?php 
 
if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
  <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          
      <div class="entry clear">
       <?php the_post_thumbnail(); ?>
       <?php the_content(); ?>
    </div>
  </div>
<?php endwhile; /* rewind or continue if all posts have been fetched */ ?>

<?php endif; ?>
<?php
 
 ?>
 

</div>
<?php get_footer(); ?>





