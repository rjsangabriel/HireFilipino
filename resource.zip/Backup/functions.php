
<?php
/* enqueue styles and scripts */
	// smart jquery inclusion

function jpen_enqueue_assets() {
	
  
  /* boostrap resources from theme files */
  wp_enqueue_style( 'bootstrap-css' , get_template_directory_uri() . '/vendor/bootstrap/css/bootstrap.min.css' );
  /* theme's primary style.css file */
  wp_enqueue_style( 'main-css' , get_stylesheet_uri() );
  /* Font Awesome */
  wp_enqueue_style( 'font-awesome' , get_template_directory_uri() .'/vendor/font-awesome/css/font-awesome.min.css' );
  wp_enqueue_style( 'wpb-google-fonts', 'https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800', false );
wp_enqueue_style( 'wpb-google-fonts', 'https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic', false );

 

  /*conditional resources for IE 9 */
  wp_enqueue_script( 'simple-blog-html5', 'https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js' , array('jquery'), '3.7.0' );
  wp_script_add_data( 'simple-blog-html5', 'conditional', 'lt IE 9' );
  wp_enqueue_script( 'simple-blog-respondjs', 'https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js' , array('jquery'), '1.4.2' );
  wp_script_add_data( 'simple-blog-respondjs', 'conditional', 'lt IE 9' );
}
add_action( 'wp_enqueue_scripts' , 'jpen_enqueue_assets' );



if (!is_admin()) add_action("wp_enqueue_scripts", "my_jquery_enqueue", 11);
function my_jquery_enqueue() {


/*deregister*/
   wp_deregister_script('jquery');
   wp_deregister_script('jquery-easing');
   wp_deregister_script('bootstrap-js');
   wp_deregister_script('scroll-reveal');
   wp_deregister_script('magnific-popup');
   wp_deregister_script('theme-js');

     
/*profile grid
   wp_deregister_script('jquery-ui');
   wp_deregister_script('config');
   wp_deregister_script('emoji-picker');
   wp_deregister_script('emoji-area');
   wp_deregister_script('nanoscroller');
   wp_deregister_script('profile-magic-footer');
   wp_deregister_script('profile-magic-friends-public');
   wp_deregister_script('profile-magic-multistep-form');
   wp_deregister_script('tether');
   wp_deregister_script('util');
   
   
   
   
   /*register*/
   

   wp_register_script('jquery', get_template_directory_uri() . "/vendor/jquery/jquery.min.js", false);
   wp_register_script('jquery-easing', "http" . ($_SERVER['SERVER_PORT'] == 443 ? "s" : "") . "://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js", false);

   
   /*Profile Grid
   wp_register_script('jquery-ui', get_template_directory_uri() . "/vendor/jquery/jquery-ui.min.js", false);
   wp_register_script('config', get_template_directory_uri() . "/vendor/plugin-include/config.js", false);
   wp_register_script('emoji-picker', get_template_directory_uri() . "/vendor/plugin-include/emoji-picker.js", false);
   wp_register_script('emoji-area', get_template_directory_uri() . "/vendor/plugin-include/jquery.emojiarea.js", false);
   wp_register_script('nanoscroller', get_template_directory_uri() . "/vendor/plugin-include/nanoscroller.min.js", false);
   wp_register_script('profile-magic-footer', get_template_directory_uri() . "/vendor/plugin-include/profile-magic-footer.js", false);
   wp_register_script('profile-magic-friends-public', get_template_directory_uri() . "/vendor/plugin-include/profile-magic-friends-public.js", false);
   wp_register_script('profile-magic-multistep-form', get_template_directory_uri() . "/vendor/plugin-include/profile-magic-multistep-form.js", false);
   wp_register_script('tether', get_template_directory_uri() . "/vendor/plugin-include/tether.min.js", false);
   wp_register_script('util', get_template_directory_uri() . "/vendor/plugin-include/util.js", false);
   /*end*/
   
   wp_register_script('bootstrap-js', get_template_directory_uri() . "/vendor/bootstrap/js/bootstrap.min.js", false);
   wp_register_script('scroll-reveal', get_template_directory_uri() . "/vendor/scrollreveal/scrollreveal.min.js", false);
   wp_register_script('magnific-popup', get_template_directory_uri() . "/vendor/magnific-popup/jquery.magnific-popup.min.js", false);
   wp_register_script('theme-js', get_template_directory_uri() . "/js/creative.js", false);

   
   /*Enqueue*/
   wp_enqueue_script('jquery');
   wp_enqueue_script('jquery-easing');
   wp_enqueue_script('jquery-ui');
   
/* Profile Grid *
   wp_enqueue_script('config');
   wp_enqueue_script('emoji-picker');
   wp_enqueue_script('emoji-area');
   wp_enqueue_script('nanoscroller');
   wp_enqueue_script('profile-magic-footer');
   wp_enqueue_script('profile-magic-friends-public');
   wp_enqueue_script('profile-magic-multistep-form');
   wp_enqueue_script('tether');
   wp_enqueue_script('util');
/*end*/

   wp_enqueue_script('bootstrap-js');
   wp_enqueue_script('scroll-reveal');
   wp_enqueue_script('magnific-popup');
   wp_enqueue_script('theme-js');
}

/* header */

register_nav_menus( array( primary => Homemenu ) );


/*theme support*/
add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' ); 

/*widget areas*/
/*footer*/
function footer_widget_area() {
  register_sidebar( array(
    'name'          => 'footer Widget Area 1',
    'id'            => 'footer-sidebar-widget1',
    'before_widget' => '<div>',
    'after_widget'  => '</div>',
    'before_title'  => '<h2 class="section-heading">',
    'after_title'   => '</h2>',
    ));
	
	register_sidebar( array(
    'name'          => 'footer Widget Area 2',
    'id'            => 'footer-sidebar-widget2',
    'before_widget' => '<div>',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>',
    ));
	
	register_sidebar( array(
    'name'          => 'footer Widget Area 3',
    'id'            => 'footer-sidebar-widget3',
    'before_widget' => '<h5>',
    'after_widget'  => '</h5>',
    'before_title'  => '<h2 class="section-heading">',
    'after_title'   => '</h2>',
    ));
}
add_action( 'widgets_init' , 'footer_widget_area' );



/*sidebar*/
function sidebar_widget_area() {
  register_sidebar( array(
    'name'          => 'sidebar Widget Area 1',
    'id'            => 'sidebar-widget1',
    'before_widget' => '<ul class="sidebar-nav">',
    'after_widget'  => '</ul>',
    'before_title'  => '<h3>',
    'after_title'   => '</h3>',
    ));
  
  register_sidebar( array(
    'name'          => 'sidebar Widget Area 2',
    'id'            => 'sidebar-widget2',
    'before_widget' => '<span style="color: black">',
    'after_widget'  => '</span>',
    'before_title'  => '<h5 style="color: white">',
    'after_title'   => '</h5>',
    ));
  
  register_sidebar( array(
    'name'          => 'sidebar Widget Area 3',
    'id'            => 'sidebar-widget3',
    'before_widget' => '<div>',
    'after_widget'  => '</div>',
    'before_title'  => '<p>',
    'after_title'   => '</p>',
    ));
}
add_action( 'widgets_init' , 'sidebar_widget_area' );

 /*category exclutions*/
function exclude_category_home( $query ) {
if ( $query->is_home ) {
$query->set( 'cat', '-8, -9' );
}
return $query;
}
 
add_filter( 'pre_get_posts', 'exclude_category_home' );

 /*blog exclution*/
function exclude_category_blog( $query ) {
if ( $query->is_category ) {
$query->set( 'cat', '-14' );
}
return $query;
}

add_filter( 'pre_get_posts', 'exclude_category_blog' );

 /*widget exclution*/
function exclude_widget_categories($args){
    $exclude = "1,14";
    $args["exclude"] = $exclude;
    return $args;
}
add_filter("widget_categories_args","exclude_widget_categories");


/*Header loggedin*/

function my_wp_nav_menu_args( $args = '' ) {

if( is_user_logged_in() ) { 
	$args['menu'] = 'logged-in';
} else { 
	$args['menu'] = 'logged-out';
} 
	return $args;
}
add_filter( 'wp_nav_menu_args', 'my_wp_nav_menu_args' );

?>





