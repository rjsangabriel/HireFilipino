<div class="container">
<div class="col-lg-8 col-lg-offset-1">
<div class="box">
		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}

			if ( is_singular( 'attachment' ) ) {
				// Parent post navigation.
				the_post_navigation( array(
					'prev_text' => _x( '<span class="meta-nav">Published in</span><span class="post-title">%title</span>', 'Parent post link', 'twentysixteen' ),
				) );
			} elseif ( is_singular( 'post' ) ) {
				// Previous/next post navigation.
				the_post_navigation( array(
					'next_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Next:') . '</span> ' .
						'<span class="screen-reader-text">' .  '</span> ' .
						'<span class="post-title">%title</span>',
					'prev_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Previous:') . '</span> ' .
						'<span class="screen-reader-text">' . '</span> ' .
						'%title',
				) );
			}
			

			// End of the loop.
		endwhile;
		?>
        
 </div>

	</div><!-- .site-main -->
</div>